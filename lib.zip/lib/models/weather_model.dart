import 'package:flutter/material.dart';

class WeatherModel {
  final String cityname;
  final DateTime date;
  final double maxTempC;
  final double minTempC;
  final String image;
  final String weatherkind;
  final double temp;

  const WeatherModel({
    required this.cityname,
    required this.date,
    required this.image,
    required this.maxTempC,
    required this.minTempC,
    required this.temp,
    required this.weatherkind,
  });
  MaterialColor getThemeColor() {
    if (weatherkind.contains("Sunny") || weatherkind.contains("Clear")) {
      return Colors.orange;
    } else if (weatherkind.contains("Cloudy") ||
        weatherkind.contains("Overcast")) {
      return Colors.grey;
    } else if (weatherkind.contains("Rain")) {
      return Colors.blueGrey;
    } else if (weatherkind.contains("Snow")) {
      return Colors.blue;
    } else {
      return Colors.green;
    }
  }

  factory WeatherModel.fromjson(Map<String, dynamic> json) {
    return WeatherModel(
      cityname: json["location"]["name"],
      date: DateTime.parse(json["location"]["localtime"]),
      image: json["forecast"]["forecastday"][0]["day"]["condition"]["icon"],
      maxTempC: json["forecast"]["forecastday"][0]["day"]["maxtemp_c"],
      minTempC: json["forecast"]["forecastday"][0]["day"]["mintemp_c"],
      temp: json["current"]["temp_c"],
      weatherkind:
          json["forecast"]["forecastday"][0]["day"]["condition"]["text"],
    );
  }
}
